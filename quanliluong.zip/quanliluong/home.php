<h3 class="title">TỔNG QUAN</h3>
<div class="content__sumary">
    <div class="content__sumary__items">
        <div class="content__sumary__items__title">
            <h5>Tổng số nhân viên</h5>
            <a href="?action=employee.php">Chi tiết</a>
        </div>
        <div class="content__sumary__items__value">
            <img src="https://png.pngtree.com/element_our/20200610/ourlarge/pngtree-business-office-man-image_2244209.jpg" id="img-employee">
            <span id="number-employee">9.866</span>
        </div>
    </div>
    <div class="content__sumary__items">
        <div class="content__sumary__items__title">
            <h5>Lịch sử chấm công</h5>
            <a href="#">Chi tiết</a>
        </div>
        <div class="content__sumary__items__value">
        </div>
    </div>
    <div class="content__sumary__items">
        <div class="content__sumary__items__title">
            <h5>Mức lương cao nhất</h5>
            <a href="#">Chi tiết</a>
        </div>
        <div class="content__sumary__items__value">
        </div>
    </div>
</div>