<?php
$connect = new mysqli("localhost", "root", "", "quanliluong");
mysqli_set_charset($connect,"utf8");